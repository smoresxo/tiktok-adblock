chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: watchNextVideo
  });
});

function watchNextVideo() {
  function clickNextButton() {
    const nextButton = document.querySelector('button[data-e2e="arrow-right"][aria-label="Go to next video"]');
    if (nextButton) {
      nextButton.click();
      function injectGoogleFontsLink() {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
      }
      
      const toast = document.createElement('div');
      toast.classList.add('toast');
      toast.textContent = 'Skipped Ad';
      toast.style.position = 'fixed';
      toast.style.top = '-100px';
      toast.style.left = '50%';
      toast.style.transform = 'translateX(-50%)';
      toast.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
      toast.style.color = '#ffffff';
      toast.style.fontFamily = 'Poppins, sans-serif';
      toast.style.fontSize = '18px';
      toast.style.padding = '10px 20px';
      toast.style.borderRadius = '10px';
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.5s ease-in-out, top 0.5s ease-in-out';
      toast.style.zIndex = '9999999999999';
      
      const checkIcon = document.createElement('span');
      checkIcon.classList.add('check-icon');
      checkIcon.innerHTML = '&#10003;';
      checkIcon.style.color = '#ffffff';
      checkIcon.style.marginRight = '10px';
      
      toast.insertBefore(checkIcon, toast.firstChild);
      
      document.body.appendChild(toast);
      
      injectGoogleFontsLink();
      setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.top = '20px';
      }, 100);
      
      setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.top = '-100px';
        setTimeout(() => {
          toast.remove();
        }, 500);
      }, 2500);      
    }
  }

  function checkForAd() {
    const adContainer = document.querySelector('div.css-1483eyc-DivAnchorTagWrapper.e1sksq2r0 > div.css-1jl2t3q-DivAnchorTag.e1sksq2r5');
    if (adContainer) {
      clickNextButton();
      setTimeout(function() {
        checkForAd();
      }, 2000);
    } else {
      setTimeout(function() {
        checkForAd();
      }, 1);
    }
  }

  checkForAd();
  function injectGoogleFontsLink() {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  }
  
  const toast = document.createElement('div');
  toast.classList.add('toast');
  toast.textContent = 'Activated';
  toast.style.position = 'fixed';
  toast.style.top = '-100px';
  toast.style.left = '50%';
  toast.style.transform = 'translateX(-50%)';
  toast.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
  toast.style.color = '#ffffff';
  toast.style.fontFamily = 'Poppins, sans-serif';
  toast.style.fontSize = '18px';
  toast.style.padding = '10px 20px';
  toast.style.borderRadius = '10px';
  toast.style.opacity = '0';
  toast.style.transition = 'opacity 0.5s ease-in-out, top 0.5s ease-in-out';
  toast.style.zIndex = '9999999999999';
  
  const checkIcon = document.createElement('span');
  checkIcon.classList.add('check-icon');
  checkIcon.innerHTML = '&#10003;';
  checkIcon.style.color = '#ffffff';
  checkIcon.style.marginRight = '10px';
  
  toast.insertBefore(checkIcon, toast.firstChild);
  
  document.body.appendChild(toast);
  
  injectGoogleFontsLink();
  setTimeout(() => {
    toast.style.opacity = '1';
    toast.style.top = '20px';
  }, 100);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.top = '-100px';
    setTimeout(() => {
      toast.remove();
    }, 500);
  }, 2500);
  
}